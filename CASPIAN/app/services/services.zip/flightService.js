﻿'use strict';
app.factory('flightService', ['$http', '$q', 'ngAuthSettings', '$rootScope', function ($http, $q, ngAuthSettings, $rootScope) {



    var serviceFactory = {};
    var _getRoutes = function (airlineid) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/routes/airline/' + airlineid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getRoute = function (from,to) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/route/' + from+'/'+to).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/flights/routes/destination/airline/{id}/{from}
    var _getRouteDestination = function (airlineid,from) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/routes/destination/airline/' + airlineid+'/'+from).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getAirportByIATA = function (iata) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/airport/iata/' + iata  ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getAverageRouteTime = function (from,to) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/routes/averagetime/' + from+'/'+to).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlights = function (cid) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/customer/' + cid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getBoxFlights = function (bid) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/box/' + bid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/plan/checkerrors/{id}
    var _checkPlanErrors = function (id) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/plan/checkerrors/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightsGrouped = function (cid,from,to) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/grouped/' + cid+'/'+from+'/'+to).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightsByRegister = function (cid, airport,register,from,to) {

        //odata/flights/register/{cid}/{airport}/{register}/{from}/{to}

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/register/' + cid + '/'+airport+'/'+register+'/' + from + '/' + to).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getDelayCodes = function () {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/delaycodes' ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getDelayCodeCats = function () {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/delaycodecats').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightDelayCodes = function (fid) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/delaycodes/'+fid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightDelays = function (fid) {



        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/' + fid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getUpdatedFlights = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flights/updated/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanBase = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/base/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItemsGantt = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/items/gantt/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItemsGanttCrewTest = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/items/gantt/crewtest', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItemsGanttCrewAssignReg = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/items/gantt/crew/assign/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //getPlanLastItem
    var _getPlanLastItem = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/last/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanLastItemByPlan = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/last/id/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItems = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/items/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItemsById = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/items/id', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightsGantt = function (cid,from,to,tzoffset,airport,filter) {
        var url = serviceBase + 'odata/flights/gantt/customer/' + cid + '/' + from + '/' + to + '/' + tzoffset;
        if (airport)
            url += '/' + airport;
         
        ///{fstatus?}/{ftypes?}/{fregsiters?}/{ffrom?}/{fto?}
         
    //    public class FlightsFilter {
    //        public List<int> Status { get; set; }
    //    public List < int > Types { get; set; }
    //    public List < int > Registers { get; set; }
    //    public List < int > From { get; set; }
    //    public List < int > To { get; set; }

    //}


        var deferred = $q.defer();
        $http.post(url,  
             filter
        ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getFlightsGanttByFlights = function (fids, tzoffset, airport, filter) {
        var url = serviceBase + 'odata/flights/gantt/' + fids + '/'  + tzoffset;
        if (airport)
            url += '/' + airport;

        

        var deferred = $q.defer();
        $http.post(url,
             filter
        ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getPlanGantt = function (cid, from, to, tzoffset, airport, filter) {
        var url = serviceBase + 'odata/plan/gantt/customer/' + cid + '/' + from + '/' + to + '/' + tzoffset;
        if (airport)
            url += '/' + airport;

         

        var deferred = $q.defer();
        $http.post(url,
             filter
        ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getFlight = function (id) {
        var offset = -1 * (new Date()).getTimezoneOffset();
        var url = serviceBase + 'odata/flight/' + id + '/' + offset ;
         
        var deferred = $q.defer();
        $http.get(url).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _getFlightPlanGantt = function (pid,offset) {
         
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplanitems/gantt/plan/' + pid + '/' + offset+'/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlan  = function ( id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplan/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanItem = function (id,offset) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flight/plan/item/' + id+'/'+offset).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getPlanItemBoard = function (id, offset) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/plan/item/' + id + '/' + offset).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanView = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplan/view/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanSummary = function (id,offset) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplan/summary/' + id + '/' + offset).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanAssignedRegisters = function (id,offset) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplans/registers/assigned/' + id+'/'+ offset + '/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _checkOverlap = function (pid,vid,rid,from,to) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplan/register/overlaps/'+pid+'/'+vid+'/'+rid+'/'+from+'/'+to ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanItems = function (pid,offset) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flightplanitems/plan/' + pid + '/' + offset+'/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanItemPermits = function (id,caid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/plan/item/permits/' + id  + '/'+caid+'/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/flights/plan/crew/{id}/{calanderId}
    var _getFlightPlanCrew = function (id, caid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/plan/crew/' + id + '/' + caid + '/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPlanCrewBox = function (boxid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/plan/crew/box/' + boxid  ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getBoxCrew = function (boxid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/box/crew/' + boxid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightCrew2 = function (flightid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flight/crew/2/' + flightid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCrewFlights = function (id,df,dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/report/flights/' + id+'?from='+_df+'&to='+_dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCrewFlightsTotal = function (df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/report/flights/total/?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCrewSummary = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/summary/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCrew = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/crew', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getCrewGrouped = function (cid, cockpit) {
        var url = 'odata/crew/cockpit/ordered/group/' + cid;
         
        if (!cockpit)
            url = 'odata/crew/cabin/ordered/group/' + cid;
       
        var deferred = $q.defer();
        $http.get($rootScope.serviceUrl + url).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _getFlightPlanPermits = function (id, caid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/plan/permits/' + id + '/' + caid + '/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightPermits = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/plan/permits/' ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightsAbnormal = function (cid,airport,std) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flights/abnormal/' + cid + '/' + airport + '/'+std+'/').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //"odata/crew/rest/check/{date}/{pid}"
    var _getRestDayOffCheck = function (date, pid) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/rest/check/' + date + '/' + pid).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/crew/rest/validation/{boxid}/{pid}
    var _getRestValidation = function (boxid, pid ) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/rest/validation/' + boxid + '/' + pid ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/crew/over/{date}/{pid}/{duty}/{flight}
    var _getOverDuty = function (date,pid,duty,flight) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/over/' + date + '/' + pid + '/' + duty + '/'+flight).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    //odata/crew/calendar/save
    var _saveCrewCalendar = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/crew/calendar/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/flight/plan/crew/save
    var _saveFlightPlanCrew = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/plan/crew/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _offFlights = function (entity,callback) {
        //odata/fdpitems/onoff
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/fdpitems/onoff', entity).then(function (response) {
            
            deferred.resolve(response.data);
            if (callback)
                callback();
           
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });
    };
    var _boxItems = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/items/box', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _createFDP = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/fdp/create', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _unboxItems = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/items/unbox', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlight = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightRegister = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/register/assign', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/flight/register/change
    var _saveFlightRegisterChange = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/register/change', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightAppy = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/apply/'+id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlanItems = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplanitems/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _makePlanEditable = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/editable/' + id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _saveFlightPlanItemPermit = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flights/plan/item/permits/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _savePlanItem = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/planitem/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _updatePlanItemFlight = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/planitem/flight/update', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlanItemBoard = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/planitems/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/flight/planitem/delete
    var _deletePlanItem = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/planitem/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deletePlanItemBoard = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/planitem/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deleteFlightPlanCrew = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/plan/crew/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deleteFlight = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deleteBoxCrew = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/box/crew/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deletePlanRegister = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/plan/register/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _deletePlanItemPermit = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/plan/item/permit/delete', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlanRegisters = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/registers/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlanRegister = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/register/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _lockPlanRegister = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/register/lock', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _unlockPlanRegister = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/register/unlock', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlanInterval = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/plan/interval/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _approvePlanRegisters = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/registers/approve', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _applyPlanCalander = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/calander/apply', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _closePlan = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/close/'+id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _approvePlan60 = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/approve/60/' + id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _approvePlan70 = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/approve/70/' + id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _savePlan = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flightplan/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightDep = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/departure/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightLog = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/log/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightDelays = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/delays/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightArr = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/arrival/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _saveFlightOffBlock = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/offblock', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveReportingTime = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/crew/reportingtime', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightOnBlock = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/onblock', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    
    var _saveFlightTakeOff = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/takeoff', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _saveFlightLanding = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/landing', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightCancel = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/cancel', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightRamp = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/ramp', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    
    var _saveFlightRedirect = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/redirect', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightPax = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/pax', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightCargo = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/cargo', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightFuelArrival = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/fuel/arrival', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _saveFlightFuelDeparture = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/flight/fuel/departure', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getCabinPositions = function () {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/options/1156').then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCockpitPositions = function () {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/options/1159' ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _getDelaysTotalByCode = function (id, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/total/code/' + id + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //gigi
    var _getSummary = function (id, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/summary/' + id + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysTotalBySource = function (id, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/total/source/' + id + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysTotalByRegister = function (id, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/total/register/' + id + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysTotalByRoute = function (id, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/total/route/' + id + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };



    var _getDelaysDetailsByCode = function (id,code, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/details/code/' + id +'/'+code+'/'+ '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysDetailsBySource = function (id, source, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/details/source/' + id + '/' + source + '/' + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysDetailsByRegister = function (id, register, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/details/register/' + id + '/' + register + '/' + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getDelaysDetailsByRoute = function (id, route, df, dt) {
        var _df = moment(df).format('YYYY-MM-DDTHH:mm:ss');
        var _dt = moment(dt).format('YYYY-MM-DDTHH:mm:ss');
        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/delays/details/route/' + id + '/' + route + '/' + '?from=' + _df + '&to=' + _dt).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    //odata/fdp/children/
    var _getFDPChildren = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/fdp/children/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _notifyFDPCrew = function (id) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/fdp/notify/' + id, null).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getFDPAssignedCrew = function (fdp) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/fdp/assigned/'+fdp).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    //GetFlights
    //odata/fights/
    var _getFlights = function (entity) {
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/fights/', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    
    var _getFlightCrews = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flight/crews/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getFlightFDPs = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/flight/fdps/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getJLData = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/jldata/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCLData = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/cldata/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _getJLDataLegs = function (ids) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/jldata/legs/' + ids).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
    var _getCLDataLegs = function (ids) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/cldata/legs/' + ids).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getFlightsLine = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/line/flights/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };


    var _getReporting = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/fdps/reporting/' + id).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };

    var _getFDPs = function (cockpit,year,month) {
        var url = 'odata/fdps/cockpit/' + year + '/' + month;
        if (!cockpit)
        {
            url = 'odata/fdps/cabin/' + year + '/' + month;
        }
        var deferred = $q.defer();
        $http.get(serviceBase + url).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
     var _getValidCrew  = function ( fdp,isvalid,cockpit) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/crew/assign/valid/'+fdp+'/'+isvalid+'/'+cockpit).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
     };
     var _getValidFDP = function (pid, year, month) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/assign/valid/' + pid + '/' + year + '/' + month).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getValidFDPDay = function (pid, year, month,day) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/assign/valid/' + pid + '/' + year + '/' + month+'/'+day).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getCrewFDPByYearMonth = function (crewid,year,month) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/crew/' + crewid + '/' + year + '/' + month).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getFDPsByYearMonth = function (year, month) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/'  + year + '/' + month+'?$orderby=DutyStart').then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveAssignFDPToCrew = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/crew/assign/fdp', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveAssignFDPToCrews = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/crews/assign/fdp', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
    //odata/crews/assign/fdp
     var _saveAssignFDPToCrew2 = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/crew/assign/fdp2', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveAssignFDPToCrew2Detail = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/crew/assign/fdp2/detail', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveUpdateFDPPosition = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/crew/assign/fdp/position', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _saveDeleteFDP = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/fdp/delete', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveDuty = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/duty/save', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveDutyDetail = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/duty/save/detail', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _IsRERRPValid = function (pid, start, end) {
         var _start = moment(start).format('YYYY-MM-DDTHH:mm:ss');
         var _end = moment(end).format('YYYY-MM-DDTHH:mm:ss');
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/isrerrpvalid/' + pid + '?start=' + _start + '&end=' + _end).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

    //odata/fdp/isevent/{pid}/{type}
     var _IsEventValid = function (pid, start, end,type) {
         var _start = moment(start).format('YYYY-MM-DDTHH:mm:ss');
         var _end = moment(end).format('YYYY-MM-DDTHH:mm:ss');
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/isevent/' + pid + '/'+type+'?start=' + _start + '&end=' + _end).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _saveAog = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/aog/save', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getAogs = function (id) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/aogs/'+id).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _saveDeleteAog = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/aog/delete', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _saveRoute = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/routes/save', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _deleteRoute = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/routes/delete', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
    ///////////////////
     var _saveDelayCode = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/delaycodes/save', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _deleteDelayCode = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/delaycodes/delete', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getDelayCode = function (id) {



         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/flights/delaycodes/' + id).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getDailyRosterCrew = function (dt) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/roster/daily/crew?date=' + dt).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getDailyRosterFlights = function (dt,id) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/roster/daily/crew/flight/'+id+'?date=' + dt).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getSecurityRoster = function (_df,_dt ) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/flight/report/security?dt=' + _dt + '&df=' + _df).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getSecurityRosterDH = function (_df, _dt) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/flight/report/security/dh?dt=' + _dt + '&df=' + _df).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };



     var _notifyDailyRoster = function (entity) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/notify/roster/daily/', entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getBoardSummary = function (cid,year,month,day) {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/board/summary/' + cid + '/'+year+'/'+month+'/'+day).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };
     var _getBoardSummaryTotal = function (cid, year, month, day,year2, month2, day2) {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/board/summary/total/' + cid + '/' + year + '/' + month + '/' + day+'/'+year2+'/'+month2+'/'+day2).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };


     var _roster = function (entity,df,dt) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/roster/method?df='+df+'&dt='+dt, entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _rosterValidate = function (entity, df, dt) {
         var deferred = $q.defer();
         $http.post($rootScope.serviceUrl + 'odata/roster/method/validate?df=' + df + '&dt=' + dt, entity).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getRosterSheet = function (_df, _dt) {

         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/roster/sheet?dt=' + _dt + '&df=' + _df).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getCrewForRoster = function (cid) {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/crew/valid/1'  ).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getCrewDutyFlight = function (dt) {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/crew/dutyflight?df='+dt).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _getFDPStats = function (ids) {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/fdp/stat/' + ids).then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

     var _deleteKeys = function () {
         var deferred = $q.defer();
         $http.get(serviceBase + 'odata/delete/keys').then(function (response) {
             deferred.resolve(response.data);
         }, function (err, status) {

             deferred.reject(Exceptions.getMessage(err));
         });

         return deferred.promise;
     };

    serviceFactory.deleteKeys = _deleteKeys;
    serviceFactory.getFDPStats = _getFDPStats;
    serviceFactory.getCrewForRoster = _getCrewForRoster;
    serviceFactory.getCrewDutyFlight = _getCrewDutyFlight;
    serviceFactory.getDelayCodes = _getDelayCodes;
    serviceFactory.getDelayCodeCats = _getDelayCodeCats;
    serviceFactory.getFlightDelayCodes = _getFlightDelayCodes;
    serviceFactory.getFlightDelays = _getFlightDelays;
    serviceFactory.getAverageRouteTime = _getAverageRouteTime;
    serviceFactory.getFlights = _getFlights;
    serviceFactory.getBoxFlights = _getBoxFlights;
    serviceFactory.getFlightPlan = _getFlightPlan;
    serviceFactory.getFlightPlanItem = _getFlightPlanItem;
    serviceFactory.getPlanItemBoard = _getPlanItemBoard;
    serviceFactory.checkOverlap = _checkOverlap;
    serviceFactory.getFlightPlanItems = _getFlightPlanItems;
    serviceFactory.getFlightsGantt = _getFlightsGantt;
    serviceFactory.getFlightsGanttByFlights = _getFlightsGanttByFlights;
    serviceFactory.getFlightPlanGantt = _getFlightPlanGantt;
    serviceFactory.savePlanItems = _savePlanItems;
    serviceFactory.makePlanEditable = _makePlanEditable;
    serviceFactory.getFlightPlanItemPermits = _getFlightPlanItemPermits;
    serviceFactory.getFlightPlanCrew = _getFlightPlanCrew;
    serviceFactory.getFlightPlanCrewBox = _getFlightPlanCrewBox;
    serviceFactory.getBoxCrew = _getBoxCrew;
    serviceFactory.getFlightCrew2 = _getFlightCrew2;
    serviceFactory.getCrewFlights = _getCrewFlights;
    serviceFactory.getCrewFlightsTotal = _getCrewFlightsTotal;
    serviceFactory.getCrewSummary = _getCrewSummary;
    serviceFactory.getCrew  = _getCrew ;
    serviceFactory.getFlightPlanPermits = _getFlightPlanPermits;
    serviceFactory.getFlightPermits = _getFlightPermits;
    serviceFactory.savePlanItem = _savePlanItem;
    serviceFactory.updatePlanItemFlight = _updatePlanItemFlight;
    serviceFactory.savePlanItemBoard = _savePlanItemBoard;
    serviceFactory.deleteFlightPlanCrew = _deleteFlightPlanCrew;
    serviceFactory.deleteFlight = _deleteFlight;
    serviceFactory.deleteBoxCrew = _deleteBoxCrew;
    serviceFactory.deletePlanItem = _deletePlanItem;
    serviceFactory.deletePlanItemBoard = _deletePlanItemBoard;
    serviceFactory.deletePlanItemPermit = _deletePlanItemPermit;
    serviceFactory.deletePlanRegister = _deletePlanRegister;
    serviceFactory.lockPlanRegister = _lockPlanRegister;
    serviceFactory.unlockPlanRegister = _unlockPlanRegister;

    serviceFactory.savePlan = _savePlan;
    serviceFactory.savePlanRegisters = _savePlanRegisters;
    serviceFactory.savePlanRegister = _savePlanRegister;
    serviceFactory.savePlanInterval = _savePlanInterval;
    serviceFactory.approvePlanRegisters = _approvePlanRegisters;
    serviceFactory.applyPlanCalander = _applyPlanCalander;
    serviceFactory.offFlights = _offFlights;
    serviceFactory.boxItems = _boxItems;
    serviceFactory.createFDP = _createFDP;
    serviceFactory.unboxItems = _unboxItems;
    serviceFactory.saveFlightPlanCrew = _saveFlightPlanCrew;
    serviceFactory.saveCrewCalendar = _saveCrewCalendar;
    serviceFactory.saveFlightDep = _saveFlightDep;
    serviceFactory.saveFlightLog = _saveFlightLog;
    serviceFactory.saveFlightDelays = _saveFlightDelays;
    serviceFactory.saveFlightArr = _saveFlightArr;
    serviceFactory.saveFlightOffBlock = _saveFlightOffBlock;
    serviceFactory.saveReportingTime = _saveReportingTime;
    serviceFactory.saveFlightTakeOff = _saveFlightTakeOff;
    serviceFactory.saveFlightLanding = _saveFlightLanding;
    serviceFactory.saveFlightOnBlock = _saveFlightOnBlock;
    serviceFactory.saveFlightPax= _saveFlightPax;
    serviceFactory.saveFlightCargo= _saveFlightCargo;
    serviceFactory.saveFlightFuelArrival= _saveFlightFuelArrival;
    serviceFactory.saveFlightFuelDeparture = _saveFlightFuelDeparture;
    serviceFactory.saveFlightPlanItemPermit = _saveFlightPlanItemPermit;
    serviceFactory.getAirportByIATA = _getAirportByIATA;
    serviceFactory.getUpdatedFlights = _getUpdatedFlights;
    serviceFactory.getRoutes = _getRoutes;
    serviceFactory.getRouteDestination = _getRouteDestination;
    serviceFactory.closePlan = _closePlan;
    serviceFactory.getFlightPlanView = _getFlightPlanView;
    serviceFactory.approvePlan60 = _approvePlan60;
    serviceFactory.approvePlan70 = _approvePlan70;
    serviceFactory.getFlightPlanAssignedRegisters = _getFlightPlanAssignedRegisters;
    serviceFactory.getFlightPlanSummary = _getFlightPlanSummary;
    serviceFactory.saveFlight = _saveFlight;
    serviceFactory.getFlightsAbnormal = _getFlightsAbnormal;
    serviceFactory.getOverDuty = _getOverDuty;
    serviceFactory.getRestValidation = _getRestValidation;
    serviceFactory.getRestDayOffCheck = _getRestDayOffCheck;
    serviceFactory.saveFlightCancel = _saveFlightCancel;
    serviceFactory.saveFlightRamp = _saveFlightRamp;
    serviceFactory.saveFlightRedirect = _saveFlightRedirect;
    serviceFactory.getRoute = _getRoute;
    serviceFactory.getFlight = _getFlight;
    serviceFactory.saveFlightRegister = _saveFlightRegister;
    serviceFactory.saveFlightAppy = _saveFlightAppy;
    serviceFactory.getFlightsGrouped = _getFlightsGrouped;
    serviceFactory.checkPlanErrors = _checkPlanErrors;
    serviceFactory.getFlightsByRegister = _getFlightsByRegister;
    serviceFactory.getPlanBase = _getPlanBase;
    serviceFactory.getPlanItemsGantt = _getPlanItemsGantt;
    serviceFactory.getPlanItemsGanttCrewTest = _getPlanItemsGanttCrewTest;
    serviceFactory.getPlanItemsGanttCrewAssignReg = _getPlanItemsGanttCrewAssignReg;
    serviceFactory.getFlights = _getFlights;
    serviceFactory.getPlanLastItem = _getPlanLastItem;
    serviceFactory.getPlanLastItemByPlan = _getPlanLastItemByPlan;
    serviceFactory.getPlanItems = _getPlanItems;
    serviceFactory.getPlanItemsById = _getPlanItemsById;
    serviceFactory.saveFlightRegisterChange = _saveFlightRegisterChange;
    serviceFactory.getCockpitPositions = _getCockpitPositions;
    serviceFactory.getCabinPositions = _getCabinPositions;


    serviceFactory.getDelaysTotalByCode = _getDelaysTotalByCode;
    serviceFactory.getDelaysTotalBySource = _getDelaysTotalBySource;
    serviceFactory.getDelaysTotalByRegister = _getDelaysTotalByRegister;
    serviceFactory.getDelaysTotalByRoute = _getDelaysTotalByRoute;

    serviceFactory.getDelaysDetailsByCode = _getDelaysDetailsByCode;
    serviceFactory.getDelaysDetailsBySource = _getDelaysDetailsBySource;
    serviceFactory.getDelaysDetailsByRegister = _getDelaysDetailsByRegister;
    serviceFactory.getDelaysDetailsByRoute = _getDelaysDetailsByRoute;
    serviceFactory.getValidCrew = _getValidCrew;
    serviceFactory.getValidFDP = _getValidFDP;
    serviceFactory.getFDPAssignedCrew = _getFDPAssignedCrew;
    serviceFactory.saveAssignFDPToCrew = _saveAssignFDPToCrew;
    serviceFactory.saveAssignFDPToCrews = _saveAssignFDPToCrews;
    serviceFactory.saveAssignFDPToCrew2 = _saveAssignFDPToCrew2;
    serviceFactory.saveAssignFDPToCrew2Detail = _saveAssignFDPToCrew2Detail;
    serviceFactory.saveUpdateFDPPosition = _saveUpdateFDPPosition;
    serviceFactory.saveDeleteFDP = _saveDeleteFDP;
    serviceFactory.getCrewFDPByYearMonth = _getCrewFDPByYearMonth;
    serviceFactory.getFDPsByYearMonth = _getFDPsByYearMonth;
    serviceFactory.IsRERRPValid = _IsRERRPValid;
    serviceFactory.IsEventValid = _IsEventValid;
    serviceFactory.saveDuty = _saveDuty;
    serviceFactory.saveDutyDetail = _saveDutyDetail;
    serviceFactory.getCrewGrouped = _getCrewGrouped;
    serviceFactory.getFDPs = _getFDPs;
    serviceFactory.getFlightFDPs = _getFlightFDPs;
    serviceFactory.getFlightCrews = _getFlightCrews;
    serviceFactory.getValidFDPDay = _getValidFDPDay;
    serviceFactory.getFDPChildren = _getFDPChildren;
    serviceFactory.notifyFDPCrew = _notifyFDPCrew;
    serviceFactory.getJLData = _getJLData;
    serviceFactory.getCLData = _getCLData;
     serviceFactory.getJLDataLegs = _getJLDataLegs;
     serviceFactory.getCLDataLegs = _getCLDataLegs;
     serviceFactory.getFlightsLine = _getFlightsLine;
    serviceFactory.getReporting = _getReporting;
    serviceFactory.saveAog = _saveAog;
    serviceFactory.getAogs = _getAogs;
    serviceFactory.saveDeleteAog = _saveDeleteAog;
    serviceFactory.saveRoute =  _saveRoute;
    serviceFactory.deleteRoute = _deleteRoute;

    serviceFactory.saveDelayCode = _saveDelayCode;
    serviceFactory.deleteDelayCode = _deleteDelayCode;
    serviceFactory.getDelayCode = _getDelayCode;
    serviceFactory.getDailyRosterCrew = _getDailyRosterCrew;
    serviceFactory.getDailyRosterFlights = _getDailyRosterFlights;
    serviceFactory.notifyDailyRoster = _notifyDailyRoster;

    serviceFactory.getBoardSummary = _getBoardSummary;
    serviceFactory.getBoardSummaryTotal = _getBoardSummaryTotal;
    serviceFactory.getSecurityRoster = _getSecurityRoster;
    serviceFactory.getSecurityRosterDH = _getSecurityRosterDH;
    serviceFactory.getSummary = _getSummary;
    serviceFactory.getPlanGantt = _getPlanGantt;

    serviceFactory.roster = _roster;
    serviceFactory.rosterValidate = _rosterValidate;
    serviceFactory.getRosterSheet = _getRosterSheet;


    return serviceFactory;

}]);