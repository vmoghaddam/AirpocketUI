﻿'use strict';
app.factory('notificationService', ['$http', '$q', 'ngAuthSettings', '$rootScope', function ($http, $q, ngAuthSettings, $rootScope) {



    var serviceFactory = {};
     
    var _getNotification = function (id) {

        var deferred = $q.defer();
        $http.get(serviceBase + 'odata/notification/' +  id  ).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
    };
     
    var _notify = function (entity) {
        entity.SenderId = $rootScope.userId;
         
        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/notifications/save', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;
        
        
    };

    var _notify2 = function (entity) {
        entity.SenderId = $rootScope.userId;

        var deferred = $q.defer();
        $http.post($rootScope.serviceUrl + 'odata/notifications/save2', entity).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;


    };

    var _sms = function (atext,nos) {
        var sms = {
            username: '9125591790',
            password: '@khavaN559',
            to: nos,
            //from: '2000800',
            from:'30001223136323',
            text:atext,

        };

        var deferred = $q.defer();
        $http.post(  'https://rest.payamak-panel.com/api/SendSMS/SendSMS', sms).then(function (response) {
            deferred.resolve(response.data);
        }, function (err, status) {

            deferred.reject(Exceptions.getMessage(err));
        });

        return deferred.promise;


    };
    
    serviceFactory.notify = _notify;
    serviceFactory.notify2 = _notify2;
    serviceFactory.getNotification = _getNotification;
    serviceFactory.sms = _sms;
    //serviceFactory.delete = _delete;
    return serviceFactory;

}]);